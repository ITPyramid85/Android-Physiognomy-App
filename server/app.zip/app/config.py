from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "gemma-4-E2B-it.litertlm"
MODELS_DIR = ROOT / "models"
CACHE_DIR = ROOT / ".cache"
FACE_TASK = MODELS_DIR / "face_landmarker.task"
HAND_TASK = MODELS_DIR / "hand_landmarker.task"

FACE_TASK_URL = (
    "https://storage.googleapis.com/mediapipe-models/"
    "face_landmarker/face_landmarker/float16/1/face_landmarker.task"
)
HAND_TASK_URL = (
    "https://storage.googleapis.com/mediapipe-models/"
    "hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
)

HOST = "0.0.0.0"
PORT = 8787
MAX_OUTPUT_TOKENS = 1536
TEMPERATURE = 0.7
TOP_K = 20
MAX_IMAGE_EDGE = 1280
CHAT_HISTORY_TURNS = 12
