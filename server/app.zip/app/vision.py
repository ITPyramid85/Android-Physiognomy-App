"""Face and hand measurement. Landmark models run only on this server."""

from __future__ import annotations

import math
import urllib.request
from io import BytesIO

import numpy as np
from PIL import Image, ImageOps

from . import config

_face = None
_hand = None
ready = False
error: str | None = None


class VisionError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def load() -> None:
    global _face, _hand, ready, error
    try:
        _ensure_task(config.FACE_TASK, config.FACE_TASK_URL)
        _ensure_task(config.HAND_TASK, config.HAND_TASK_URL)
        _face = _make_face()
        _hand = _make_hand()
        ready = True
        error = None
    except Exception as exc:  # noqa: BLE001 - surfaced on /health
        ready = False
        error = str(exc)
        raise


def analyze_face(image_bytes: bytes) -> dict:
    _require_ready()
    rgb, width, height = _decode(image_bytes)
    landmarks = _face_landmarks(rgb)
    if landmarks is None:
        raise VisionError("no_face", "no face detected")
    features = _face_features(landmarks)
    return {
        "score": 1.0,
        "frame_width": width,
        "frame_height": height,
        "features": features,
    }


def analyze_palm(image_bytes: bytes) -> dict:
    _require_ready()
    rgb, width, height = _decode(image_bytes)
    landmarks = _hand_landmarks(rgb)
    if landmarks is None:
        raise VisionError("no_palm", "no hand detected")
    features = _palm_features(landmarks)
    is_left = landmarks[4][0] > landmarks[0][0]
    features_out = dict(features)
    return {
        "score": 1.0,
        "frame_width": width,
        "frame_height": height,
        "is_left_hand": is_left,
        "features": features_out,
    }


def _require_ready() -> None:
    if not ready or _face is None or _hand is None:
        raise VisionError("model", error or "vision models are not loaded")


def _ensure_task(path, url: str) -> None:
    if path.is_file() and path.stat().st_size > 0:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    urllib.request.urlretrieve(url, path)


def _make_face():
    import mediapipe as mp
    from mediapipe.tasks import python
    from mediapipe.tasks.python import vision

    options = vision.FaceLandmarkerOptions(
        base_options=python.BaseOptions(model_asset_path=str(config.FACE_TASK)),
        running_mode=vision.RunningMode.IMAGE,
        num_faces=1,
        min_face_detection_confidence=0.5,
    )
    return vision.FaceLandmarker.create_from_options(options), mp


def _make_hand():
    import mediapipe as mp
    from mediapipe.tasks import python
    from mediapipe.tasks.python import vision

    options = vision.HandLandmarkerOptions(
        base_options=python.BaseOptions(model_asset_path=str(config.HAND_TASK)),
        running_mode=vision.RunningMode.IMAGE,
        num_hands=1,
        min_hand_detection_confidence=0.6,
        min_hand_presence_confidence=0.6,
    )
    return vision.HandLandmarker.create_from_options(options), mp


def _decode(image_bytes: bytes) -> tuple[np.ndarray, int, int]:
    try:
        image = Image.open(BytesIO(image_bytes))
        image = ImageOps.exif_transpose(image).convert("RGB")
    except Exception as exc:  # noqa: BLE001
        raise VisionError("bad_image", "could not read image") from exc
    image = _limit_edge(image, config.MAX_IMAGE_EDGE)
    array = np.asarray(image)
    return array, image.width, image.height


def _limit_edge(image: Image.Image, max_edge: int) -> Image.Image:
    if max(image.size) <= max_edge:
        return image
    scale = max_edge / max(image.size)
    size = (max(1, int(image.width * scale)), max(1, int(image.height * scale)))
    return image.resize(size, Image.Resampling.LANCZOS)


def _mp_image(pair, rgb: np.ndarray):
    _, mp = pair
    return mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)


def _face_landmarks(rgb: np.ndarray) -> list[tuple[float, float, float]] | None:
    result = _face[0].detect(_mp_image(_face, rgb))
    faces = result.face_landmarks or []
    if not faces:
        return None
    points = [(p.x, p.y, p.z) for p in faces[0]]
    if len(points) < 468:
        return None
    return points


def _hand_landmarks(rgb: np.ndarray) -> list[tuple[float, float, float]] | None:
    result = _hand[0].detect(_mp_image(_hand, rgb))
    hands = result.hand_landmarks or []
    if not hands:
        return None
    points = [(p.x, p.y, p.z) for p in hands[0]]
    if len(points) < 21:
        return None
    return points


def _face_features(lm: list[tuple[float, float, float]]) -> dict:
    def x(index: int) -> float:
        return lm[index][0]

    def y(index: int) -> float:
        return lm[index][1]

    eye_span = abs(x(362) - x(133))
    face_height = abs(y(152) - y(10))
    nose_ratio = (y(4) - y(10)) / face_height if face_height > 1e-6 else 0.0
    return {
        "eyeSpan": eye_span,
        "faceHeight": face_height,
        "noseRatio": nose_ratio,
        "mouthWidth": abs(x(291) - x(61)),
        "symmetry": abs((x(4) - x(133)) - (x(362) - x(4))),
        "foreheadHeight": abs(y(168) - y(10)),
        "eyebrowDistance": abs(y(107) - y(133)),
    }


def _palm_features(lm: list[tuple[float, float, float]]) -> dict:
    def dist(a: int, b: int) -> float:
        dx = lm[a][0] - lm[b][0]
        dy = lm[a][1] - lm[b][1]
        return math.sqrt(dx * dx + dy * dy)

    tips = [lm[4][0], lm[8][0], lm[12][0], lm[16][0], lm[20][0]]
    mean_x = sum(tips) / len(tips)
    variance = sum((x - mean_x) ** 2 for x in tips) / len(tips)
    return {
        "palmWidth": dist(5, 17),
        "indexLength": dist(5, 8),
        "middleLength": dist(9, 12),
        "ringLength": dist(13, 16),
        "pinkyLength": dist(17, 20),
        "thumbLength": dist(1, 4),
        "fingerSpread": math.sqrt(variance),
    }
